package com.sntg.dictionary;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

public class ProcessTextActivity extends BridgeActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // متنی که کاربر در برنامهٔ دیگر (مرورگر، PDF، دفترچه یادداشت و ...) انتخاب کرده
        CharSequence selected = getIntent().getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT);
        String selectedText = (selected != null) ? selected.toString() : "";
        String encodedWord = Uri.encode(selectedText);

        // از همان bridge/WebView داخلیِ Capacitor استفاده می‌کنیم (نه یک WebView دستی)،
        // چون این‌طوری دقیقاً همان origin (https://localhost) برنامهٔ اصلی حفظ می‌شود
        // و در نتیجه به همان IndexedDB (گلوساری‌های ذخیره‌شده) دسترسی داریم.
        getBridge().getWebView().loadUrl("https://localhost/index.html?popup=1&word=" + encodedWord);
    }
}
